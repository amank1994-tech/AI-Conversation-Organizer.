/**
 * popup.js — AI Conversation Organizer v2.1
 * Fixed in this build:
 *   - sanitizeColor() defined before first use (was missing entirely)
 *   - tabs permission removed; share opens links via window.open instead
 *   - all color injections go through sanitizeColor()
 *   - def.color in tag-picker, tag-manager, analytics bars all sanitized
 */

// ── State ─────────────────────────────────────────────────
let allConversations = [];
let customTagDefs    = [];
let activeFilter     = "All";
let searchQuery      = "";
let dateFrom         = null;
let dateTo           = null;
let analyticsPeriod  = "week";
let activeTab        = "conversations";
let tagPickerConvoId = null;
let shareConvo       = null;

// ── DOM refs ──────────────────────────────────────────────
const $ = id => document.getElementById(id);

const searchInput      = $("searchInput");
const searchClear      = $("searchClear");
const filterButtons    = $("filterButtons");
const timelineList     = $("timelineList");
const importantList    = $("importantList");
const importantSection = $("importantSection");
const importantCount   = $("importantCount");
const timelineCount    = $("timelineCount");
const convCount        = $("conversationCount");
const emptyState       = $("emptyState");
const noResultsState   = $("noResultsState");
const clearAllBtn      = $("clearAllBtn");
const clearModal       = $("clearModal");
const cancelClear      = $("cancelClear");
const confirmClear     = $("confirmClear");
const storageSize      = $("storageSize");
const timelineSection  = $("timelineSection");
const dateFromInput    = $("dateFrom");
const dateToInput      = $("dateTo");
const dateClear        = $("dateClear");
const analyticsContent = $("analyticsContent");
const newTagInput      = $("newTagInput");
const addTagBtn        = $("addTagBtn");
const customTagList    = $("customTagList");
const colorSwatches    = $("colorSwatches");
const shareModal       = $("shareModal");
const shareTitle       = $("shareTitle");
const shareUrl         = $("shareUrl");
const tagPickerModal   = $("tagPickerModal");
const tagPickerList    = $("tagPickerList");

const TAG_COLORS = [
  "#6366f1","#ec4899","#f59e0b","#22c55e",
  "#3b82f6","#ef4444","#8b5cf6","#14b8a6","#f97316","#64748b"
];
let selectedTagColor = TAG_COLORS[0];

// ── Topic color map (mirrors TOPIC_RULES in content.js) ───
const TOPIC_COLORS = {
  "Health":  "#16a34a",
  "Gym":     "#ea580c",
  "Career":  "#7c3aed",
  "AI/Tech": "#2563eb",
  "Tech":    "#0ea5e9",
  "Startup": "#db2777",
  "Writing": "#d97706",
  "Finance": "#0d9488",
  "Food":    "#65a30d",
  "Travel":  "#f59e0b",
  "General": "#6b7280"
};

// ══════════════════════════════════════════════════════════
//  UTILITIES — defined FIRST so every function below can use them
// ══════════════════════════════════════════════════════════

/**
 * Sanitizes a hex color to prevent CSS injection.
 * Accepts only #rgb or #rrggbb. Falls back to safe grey.
 */
function sanitizeColor(color) {
  if (typeof color === "string" && /^#[0-9a-fA-F]{3}(?:[0-9a-fA-F]{3})?$/.test(color)) {
    return color;
  }
  return "#6b7280";
}

/** Escapes HTML special characters to prevent XSS. */
function escapeHtml(str) {
  return String(str || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function formatRelative(iso) {
  const diff = Math.floor((Date.now() - new Date(iso).getTime()) / 1000);
  if (diff < 60)     return "Just now";
  if (diff < 3600)   return `${Math.floor(diff / 60)}m ago`;
  if (diff < 86400)  return `${Math.floor(diff / 3600)}h ago`;
  if (diff < 604800) return `${Math.floor(diff / 86400)}d ago`;
  return formatDate(iso);
}

function formatDate(iso) {
  const d = new Date(iso);
  return d.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })
    + " · " + d.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" });
}

function updateStorageDisplay() {
  const bytes = new TextEncoder().encode(JSON.stringify(allConversations)).length;
  storageSize.textContent = bytes < 1024 ? `${bytes}B` : `${(bytes / 1024).toFixed(1)}KB`;
}

// ── Init ──────────────────────────────────────────────────
document.addEventListener("DOMContentLoaded", async () => {
  [allConversations, customTagDefs] = await Promise.all([
    loadConversations(), loadCustomTagDefinitions()
  ]);
  updateStorageDisplay();
  buildFilterButtons();
  buildColorSwatches();
  renderCustomTagManager();
  render();
  bindEventListeners();
});

// ── Tab switching ─────────────────────────────────────────
function switchTab(tab) {
  activeTab = tab;
  document.querySelectorAll(".tab-btn").forEach(b =>
    b.classList.toggle("tab-btn--active", b.dataset.tab === tab));
  document.querySelectorAll(".tab-panel").forEach(p =>
    p.classList.toggle("tab-panel--active", p.id === `tab-${tab}`));
  if (tab === "analytics") renderAnalytics();
  if (tab === "tags")      renderCustomTagManager();
}

async function reload() {
  [allConversations, customTagDefs] = await Promise.all([
    loadConversations(), loadCustomTagDefinitions()
  ]);
  updateStorageDisplay();
  buildFilterButtons();
  render();
}

// ══════════════════════════════════════════════════════════
//  CONVERSATIONS TAB
// ══════════════════════════════════════════════════════════

function render() {
  const filtered   = applyFilters(allConversations);
  const bookmarked = filtered.filter(c => c.important);
  const timeline   = filtered.filter(c => !c.important);

  convCount.textContent = allConversations.length;

  if (bookmarked.length > 0) {
    importantSection.style.display = "block";
    importantCount.textContent = bookmarked.length;
    importantList.innerHTML = "";
    bookmarked.forEach(c => importantList.appendChild(createCard(c)));
  } else {
    importantSection.style.display = "none";
  }

  timelineCount.textContent = timeline.length;
  timelineList.innerHTML = "";
  timeline.forEach(c => timelineList.appendChild(createCard(c)));

  const hasResults = filtered.length > 0;
  const hasAny     = allConversations.length > 0;
  timelineSection.style.display = hasResults ? "block" : "none";
  emptyState.style.display      = !hasAny    ? "flex"  : "none";
  noResultsState.style.display  = (hasAny && !hasResults) ? "flex" : "none";
}

function applyFilters(conversations) {
  return conversations.filter(c => {
    const matchesCat =
      activeFilter === "All" ||
      c.tag === activeFilter ||
      (c.topics || []).includes(activeFilter) ||
      (c.customTags || []).includes(activeFilter);

    const q = searchQuery;
    const matchesSearch = !q ||
      c.title.toLowerCase().includes(q) ||
      c.tag.toLowerCase().includes(q) ||
      (c.topics || []).some(t => t.toLowerCase().includes(q)) ||
      (c.summary || "").toLowerCase().includes(q) ||
      (c.customTags || []).some(ct => ct.toLowerCase().includes(q));

    const ts        = new Date(c.timestamp);
    const matchFrom = !dateFrom || ts >= dateFrom;
    const matchTo   = !dateTo   || ts <= dateTo;

    return matchesCat && matchesSearch && matchFrom && matchTo;
  });
}

// ── Card ──────────────────────────────────────────────────
function createCard(convo) {
  const card = document.createElement("div");
  card.className = `card ${convo.important ? "card--bookmarked" : ""}`;
  card.dataset.id = convo.id;

  const date    = formatDate(convo.timestamp);
  const timeAgo = formatRelative(convo.timestamp);
  const summary = escapeHtml(convo.summary || "");

  // All detected topics — primary first, extras with "+" prefix
  const allTopics = (convo.topics && convo.topics.length > 0) ? convo.topics : [convo.tag];
  const topicsHtml = allTopics.map((t, i) => {
    const color = sanitizeColor(TOPIC_COLORS[t] || convo.tagColor || "#6b7280");
    const cls   = i === 0 ? "tag-badge" : "tag-badge tag-badge--secondary";
    return `<span class="${cls}" style="--tag-color:${color}">${escapeHtml(t)}</span>`;
  }).join("");

  // User-assigned custom labels
  const customTagsHtml = (convo.customTags || []).map(ct => {
    const def   = customTagDefs.find(d => d.label === ct);
    const color = sanitizeColor(def ? def.color : "#6b7280");
    return `<span class="custom-tag-badge" style="--ct-color:${color}">${escapeHtml(ct)}</span>`;
  }).join("");

  card.innerHTML = `
    <div class="card-top">
      <div class="card-tags">
        ${topicsHtml}
        ${customTagsHtml}
      </div>
      <div class="card-actions">
        <button class="btn-card-action btn-label" data-id="${convo.id}" title="Assign labels">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"/><line x1="7" y1="7" x2="7.01" y2="7"/></svg>
        </button>
        <button class="btn-card-action btn-share" data-id="${convo.id}" title="Share conversation">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/></svg>
        </button>
        <button class="btn-card-action btn-bookmark ${convo.important ? "btn-bookmark--active" : ""}"
                data-id="${convo.id}" title="${convo.important ? "Remove bookmark" : "Bookmark"}">
          <svg width="12" height="12" viewBox="0 0 24 24"
               fill="${convo.important ? "currentColor" : "none"}" stroke="currentColor" stroke-width="2">
            <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>
          </svg>
        </button>
        <button class="btn-card-action btn-delete" data-id="${convo.id}" title="Remove">
          <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
            <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
          </svg>
        </button>
      </div>
    </div>
    <p class="card-title" title="${escapeHtml(convo.title)}">${escapeHtml(convo.title)}</p>
    ${summary ? `<p class="card-summary">${summary}</p>` : ""}
    <div class="card-footer">
      <div class="card-time-block">
        <span class="card-time-relative">${timeAgo}</span>
        <span class="card-time-full">${date}</span>
      </div>
      <a href="${escapeHtml(convo.url)}" target="_blank" class="btn-open" title="Open in ChatGPT">
        Open
        <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
          <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>
          <polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/>
        </svg>
      </a>
    </div>`;

  card.querySelector(".btn-bookmark").addEventListener("click", async e => {
    e.preventDefault();
    await toggleImportant(e.currentTarget.dataset.id);
    await reload();
  });

  card.querySelector(".btn-delete").addEventListener("click", async e => {
    e.preventDefault();
    card.classList.add("card--removing");
    setTimeout(async () => {
      await deleteConversation(e.currentTarget.dataset.id);
      await reload();
    }, 220);
  });

  card.querySelector(".btn-share").addEventListener("click", e => {
    e.preventDefault();
    openShareModal(convo);
  });

  card.querySelector(".btn-label").addEventListener("click", e => {
    e.preventDefault();
    openTagPicker(convo);
  });

  return card;
}

// ── Filter buttons ────────────────────────────────────────
function buildFilterButtons() {
  const builtIn = getAllCategories();
  const custom  = customTagDefs.map(ct => ({ tag: ct.label, color: ct.color }));
  const all = [
    ...builtIn.filter(c => c.tag === "All"),
    ...builtIn.filter(c => c.tag !== "All"),
    ...custom
  ];
  filterButtons.innerHTML = "";
  all.forEach(cat => {
    const btn = document.createElement("button");
    btn.className = `filter-btn ${cat.tag === activeFilter ? "filter-btn--active" : ""}`;
    btn.textContent = cat.tag;
    btn.dataset.tag = cat.tag;
    btn.style.setProperty("--cat-color", sanitizeColor(cat.color));
    btn.addEventListener("click", () => {
      activeFilter = cat.tag;
      document.querySelectorAll(".filter-btn").forEach(b => b.classList.remove("filter-btn--active"));
      btn.classList.add("filter-btn--active");
      render();
    });
    filterButtons.appendChild(btn);
  });
}

// ══════════════════════════════════════════════════════════
//  SHARE MODAL
//  Uses window.open() instead of chrome.tabs.create()
//  so the 'tabs' permission is not needed in manifest.json
// ══════════════════════════════════════════════════════════

function openShareModal(convo) {
  shareConvo = convo;
  shareTitle.textContent = convo.title;
  shareUrl.textContent   = convo.url;
  shareModal.style.display = "flex";
}

function closeShareModal() {
  shareModal.style.display = "none";
  shareConvo = null;
}

function doShare(platform) {
  if (!shareConvo) return;
  const url  = encodeURIComponent(shareConvo.url);
  const text = encodeURIComponent(`💬 Interesting ChatGPT conversation: "${shareConvo.title}"`);
  const links = {
    twitter:  `https://twitter.com/intent/tweet?text=${text}&url=${url}`,
    linkedin: `https://www.linkedin.com/sharing/share-offsite/?url=${url}`,
    whatsapp: `https://wa.me/?text=${text}%20${url}`
  };
  if (platform === "copy") {
    navigator.clipboard.writeText(shareConvo.url).then(() => {
      const btn = $("shareCopy");
      btn.textContent = "✓ Copied!";
      setTimeout(() => {
        btn.innerHTML = `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg> Copy Link`;
      }, 2000);
    });
  } else {
    // window.open works in extension popups without any extra permissions
    window.open(links[platform], "_blank");
  }
}

// ══════════════════════════════════════════════════════════
//  TAG PICKER MODAL
// ══════════════════════════════════════════════════════════

function openTagPicker(convo) {
  tagPickerConvoId = convo.id;
  renderTagPicker(convo);
  tagPickerModal.style.display = "flex";
}

function renderTagPicker(convo) {
  tagPickerList.innerHTML = "";
  if (customTagDefs.length === 0) {
    tagPickerList.innerHTML = `<p class="no-custom-tags">No custom labels yet.<br/>Create them in the <strong>My Tags</strong> tab.</p>`;
    return;
  }
  const assigned = convo.customTags || [];
  customTagDefs.forEach(def => {
    const isOn  = assigned.includes(def.label);
    const color = sanitizeColor(def.color);
    const row   = document.createElement("label");
    row.className = "tag-picker-row";
    row.innerHTML = `
      <input type="checkbox" ${isOn ? "checked" : ""} data-label="${escapeHtml(def.label)}"/>
      <span class="tag-picker-dot" style="background:${color}"></span>
      <span class="tag-picker-label">${escapeHtml(def.label)}</span>`;
    tagPickerList.appendChild(row);
  });
}

async function saveTagPickerSelection() {
  const checkboxes = tagPickerList.querySelectorAll("input[type=checkbox]");
  const selected   = Array.from(checkboxes).filter(cb => cb.checked).map(cb => cb.dataset.label);
  await updateConversationCustomTags(tagPickerConvoId, selected);
  tagPickerModal.style.display = "none";
  await reload();
}

// ══════════════════════════════════════════════════════════
//  CUSTOM TAG MANAGER (My Tags tab)
// ══════════════════════════════════════════════════════════

function buildColorSwatches() {
  colorSwatches.innerHTML = "";
  TAG_COLORS.forEach(color => {
    const sw = document.createElement("button");
    sw.className = `color-swatch ${color === selectedTagColor ? "color-swatch--active" : ""}`;
    sw.style.background = sanitizeColor(color);
    sw.title = color;
    sw.addEventListener("click", () => {
      selectedTagColor = color;
      document.querySelectorAll(".color-swatch").forEach(s => s.classList.remove("color-swatch--active"));
      sw.classList.add("color-swatch--active");
    });
    colorSwatches.appendChild(sw);
  });
}

function renderCustomTagManager() {
  customTagList.innerHTML = "";
  if (customTagDefs.length === 0) {
    customTagList.innerHTML = `<p class="no-custom-tags">No custom labels yet. Create one above.</p>`;
    return;
  }
  customTagDefs.forEach(def => {
    const used  = allConversations.filter(c => (c.customTags || []).includes(def.label)).length;
    const color = sanitizeColor(def.color);
    const row   = document.createElement("div");
    row.className = "custom-tag-row";
    row.innerHTML = `
      <span class="custom-tag-dot" style="background:${color}"></span>
      <span class="custom-tag-name">${escapeHtml(def.label)}</span>
      <span class="custom-tag-usage">${used} conversation${used !== 1 ? "s" : ""}</span>
      <button class="btn-delete-tag" data-label="${escapeHtml(def.label)}" title="Delete label">
        <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
          <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
        </svg>
      </button>`;
    row.querySelector(".btn-delete-tag").addEventListener("click", async e => {
      await deleteCustomTagDefinition(e.currentTarget.dataset.label);
      await reload();
      renderCustomTagManager();
    });
    customTagList.appendChild(row);
  });
}

// ══════════════════════════════════════════════════════════
//  ANALYTICS TAB
// ══════════════════════════════════════════════════════════

async function renderAnalytics() {
  analyticsContent.innerHTML = `<div class="analytics-loading">Loading…</div>`;
  const data = await getAnalytics(analyticsPeriod);
  analyticsContent.innerHTML = buildAnalyticsHTML(data);
  drawActivityChart(data);
}

function buildAnalyticsHTML(data) {
  const { total, prevTotal, sortedTags, peakDay, peakCount, bookmarked, hourCounts, period } = data;
  const periodLabel = period === "week" ? "Last 7 days" : "Last 30 days";

  const diff  = total - prevTotal;
  const trend = diff > 0 ? `<span class="trend trend--up">↑ ${diff} more</span>`
              : diff < 0 ? `<span class="trend trend--down">↓ ${Math.abs(diff)} fewer</span>`
              : `<span class="trend trend--flat">→ Same</span>`;

  let peakHour = 0;
  hourCounts.forEach((v, i) => { if (v > hourCounts[peakHour]) peakHour = i; });
  const peakHourLabel = peakHour === 0   ? "12am"
                      : peakHour < 12    ? `${peakHour}am`
                      : peakHour === 12  ? "12pm"
                      : `${peakHour - 12}pm`;

  const maxTagCount = sortedTags.length > 0 ? sortedTags[0][1] : 1;
  const tagBars = sortedTags.slice(0, 6).map(([tag, count]) => {
    const pct   = Math.round((count / maxTagCount) * 100);
    // Look up color from CATEGORY_RULES (loaded via tagging.js) or TOPIC_COLORS fallback
    const rule  = (typeof CATEGORY_RULES !== "undefined")
      ? CATEGORY_RULES.find(r => r.tag === tag)
      : null;
    const color = sanitizeColor(rule ? rule.color : (TOPIC_COLORS[tag] || "#6b7280"));
    return `
      <div class="analytics-bar-row">
        <span class="analytics-bar-label">${escapeHtml(tag)}</span>
        <div class="analytics-bar-track">
          <div class="analytics-bar-fill" style="width:${pct}%;background:${color}"></div>
        </div>
        <span class="analytics-bar-count">${count}</span>
      </div>`;
  }).join("");

  const peakDayFmt = peakDay
    ? new Date(peakDay + "T12:00:00").toLocaleDateString("en-US", { month: "short", day: "numeric" })
    : "—";

  return `
    <div class="analytics-body">
      <div class="analytics-period-label">${periodLabel}</div>
      <div class="kpi-grid">
        <div class="kpi-card">
          <span class="kpi-value">${total}</span>
          <span class="kpi-label">Conversations ${trend}</span>
        </div>
        <div class="kpi-card">
          <span class="kpi-value">${sortedTags.length}</span>
          <span class="kpi-label">Topics covered</span>
        </div>
        <div class="kpi-card">
          <span class="kpi-value">${bookmarked}</span>
          <span class="kpi-label">Bookmarked</span>
        </div>
        <div class="kpi-card">
          <span class="kpi-value">${data.multiTopicCount || 0}</span>
          <span class="kpi-label">Multi-topic chats</span>
        </div>
        <div class="kpi-card">
          <span class="kpi-value">${peakCount || 0}</span>
          <span class="kpi-label">Peak day (${peakDayFmt})</span>
        </div>
      </div>
      <div class="analytics-section-title">Daily Activity</div>
      <div class="activity-chart-wrap">
        <canvas id="activityChart" height="60"></canvas>
      </div>
      <div class="analytics-insight">
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
        Most active around <strong>${peakHourLabel}</strong>
      </div>
      <div class="analytics-section-title">Topic Breakdown</div>
      ${sortedTags.length > 0
        ? `<div class="analytics-bars">${tagBars}</div>`
        : `<p class="no-data">No conversations in this period.</p>`}
      <div class="analytics-alltime">${data.allTime} conversations tracked all-time</div>
    </div>`;
}

function drawActivityChart(data) {
  const canvas = document.getElementById("activityChart");
  if (!canvas) return;
  const ctx  = canvas.getContext("2d");
  const days = analyticsPeriod === "week" ? 7 : 30;
  const counts = [];

  for (let i = days - 1; i >= 0; i--) {
    const key = new Date(Date.now() - i * 86400000).toISOString().slice(0, 10);
    counts.push(data.dailyCounts[key] || 0);
  }

  const W = canvas.offsetWidth || 360;
  canvas.width  = W;
  canvas.height = 60;

  const max  = Math.max(...counts, 1);
  const barW = W / counts.length;
  const pad  = 2;
  ctx.clearRect(0, 0, W, 60);

  counts.forEach((v, i) => {
    const h   = Math.max(3, (v / max) * 52);
    const x   = i * barW + pad;
    const y   = 60 - h;
    const pct = v / max;
    ctx.fillStyle = `rgba(99,102,241,${0.25 + pct * 0.7})`;
    ctx.beginPath();
    ctx.roundRect(x, y, barW - pad * 2, h, 2);
    ctx.fill();
  });
}

// ══════════════════════════════════════════════════════════
//  EVENT LISTENERS
// ══════════════════════════════════════════════════════════

function bindEventListeners() {
  document.querySelectorAll(".tab-btn").forEach(btn =>
    btn.addEventListener("click", () => switchTab(btn.dataset.tab)));

  searchInput.addEventListener("input", e => {
    searchQuery = e.target.value.toLowerCase().trim();
    searchClear.style.opacity       = searchQuery ? "1" : "0";
    searchClear.style.pointerEvents = searchQuery ? "all" : "none";
    render();
  });
  searchClear.addEventListener("click", () => {
    searchInput.value = ""; searchQuery = "";
    searchClear.style.opacity = "0"; searchClear.style.pointerEvents = "none";
    searchInput.focus(); render();
  });

  dateFromInput.addEventListener("change", () => {
    dateFrom = dateFromInput.value ? new Date(dateFromInput.value + "T00:00:00") : null;
    render();
  });
  dateToInput.addEventListener("change", () => {
    dateTo = dateToInput.value ? new Date(dateToInput.value + "T23:59:59") : null;
    render();
  });
  dateClear.addEventListener("click", () => {
    dateFrom = dateTo = null;
    dateFromInput.value = ""; dateToInput.value = "";
    render();
  });

  clearAllBtn.addEventListener("click", () => { clearModal.style.display = "flex"; });
  cancelClear.addEventListener("click", () => { clearModal.style.display = "none"; });
  confirmClear.addEventListener("click", async () => {
    await clearAllConversations();
    clearModal.style.display = "none";
    await reload();
  });
  clearModal.addEventListener("click", e => {
    if (e.target === clearModal) clearModal.style.display = "none";
  });

  $("shareClose").addEventListener("click", closeShareModal);
  shareModal.addEventListener("click", e => { if (e.target === shareModal) closeShareModal(); });
  $("shareTwitter").addEventListener("click",  () => doShare("twitter"));
  $("shareLinkedin").addEventListener("click", () => doShare("linkedin"));
  $("shareWhatsapp").addEventListener("click", () => doShare("whatsapp"));
  $("shareCopy").addEventListener("click",     () => doShare("copy"));

  $("tagPickerClose").addEventListener("click", saveTagPickerSelection);
  tagPickerModal.addEventListener("click", e => {
    if (e.target === tagPickerModal) saveTagPickerSelection();
  });

  addTagBtn.addEventListener("click", async () => {
    const label = newTagInput.value.trim();
    if (!label) return;
    const result = await saveCustomTagDefinition(label, selectedTagColor);
    if (result.saved) {
      newTagInput.value = "";
      await reload();
      renderCustomTagManager();
    } else {
      newTagInput.style.borderColor = "var(--danger)";
      setTimeout(() => { newTagInput.style.borderColor = ""; }, 1200);
    }
  });
  newTagInput.addEventListener("keydown", e => { if (e.key === "Enter") addTagBtn.click(); });

  document.querySelectorAll(".period-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      analyticsPeriod = btn.dataset.period;
      document.querySelectorAll(".period-btn").forEach(b => b.classList.remove("period-btn--active"));
      btn.classList.add("period-btn--active");
      renderAnalytics();
    });
  });
}
