/**
 * tagging.js — v2.2
 * Keyword rules for auto-categorising conversation titles.
 * Also used by popup.js for filter button generation.
 * Keep CATEGORY_RULES in sync with TOPIC_RULES in content.js.
 */

const CATEGORY_RULES = [
  {
    tag: "Health", color: "#16a34a",
    keywords: [
      "health","diet","stress","sleep","skin","skincare","acne","ovary","ovaries",
      "mental health","anxiety","depression","nutrition","vitamin","medicine","doctor",
      "symptom","wellness","therapy","pain","headache","disease","hair","weight loss",
      "moisturizer","sunscreen","serum","hormones","period","pregnancy","blood pressure",
      "diabetes","allergy","inflammation","immune","gut","digestion","clinic",
      "supplement","bmi","body fat","dermatology","skincare routine","retinol","collagen"
    ]
  },
  {
    tag: "Gym", color: "#ea580c",
    keywords: [
      "gym","workout","protein","exercise","fitness","muscle","weight lifting",
      "lift","cardio","training","bench press","squat","run","marathon","calories",
      "bulk","cut","gains","crossfit","yoga","stretching","push up","pull up",
      "kettlebell","dumbbell","barbell","hiit","plank","abs","bicep","glutes"
    ]
  },
  {
    tag: "Career", color: "#7c3aed",
    keywords: [
      "job","resume","cv","interview","career","work","salary","hire","hiring",
      "linkedin","portfolio","cover letter","promotion","freelance","internship",
      "job offer","negotiation","manager","employee","performance review",
      "resignation","layoff","fired","remote work","side hustle","networking",
      "job search","recruiter","linkedin profile"
    ]
  },
  {
    tag: "AI/Tech", color: "#2563eb",
    keywords: [
      "machine learning","python","model","rag","gpt","llm","neural network",
      "deep learning","programming","api","javascript","react","sql","database",
      "algorithm","data science","tensorflow","pytorch","automation","software",
      "developer","debug","typescript","cloud","aws","docker","kubernetes",
      "git","backend","frontend","devops","microservices","rest api","graphql",
      "web scraping","artificial intelligence","chatbot","prompt engineering",
      "fine tuning","embeddings","vector database","langchain"
    ]
  },
  {
    // Consumer electronics & everyday tech
    tag: "Tech", color: "#0ea5e9",
    keywords: [
      "iphone","android","samsung","apple","macbook","laptop","computer","pc",
      "windows","macos","linux","phone","tablet","ipad","pixel","smartphone",
      "airpods","headphones","speaker","monitor","keyboard","mouse","graphics card",
      "gpu","cpu","ram","ssd","hard drive","wifi","router","bluetooth",
      "smartwatch","apple watch","camera","gaming","ps5","xbox","nintendo","steam",
      "streaming","netflix","spotify","youtube","instagram","tiktok","facebook",
      "twitter","reddit","tech review","gadget","device","smart home",
      "alexa","siri","google assistant","cybersecurity","vpn","password"
    ]
  },
  {
    tag: "Startup", color: "#db2777",
    keywords: [
      "startup","business idea","product","saas","mvp","founder","investor",
      "pitch","revenue","market","launch","entrepreneur","venture","funding",
      "b2b","b2c","growth","monetize","brand","go-to-market","customer acquisition",
      "churn","mrr","arr","burn rate","runway","seed round","series a",
      "product market fit","user research","business model","value proposition"
    ]
  },
  {
    tag: "Writing", color: "#d97706",
    keywords: [
      "write","essay","blog","article","story","email","letter","content",
      "copywriting","edit","draft","poem","script","novel","summarize","summary",
      "report","thesis","grammar","proofreading","headline","caption",
      "newsletter","paraphrase","rewrite","tone","creative writing","fiction"
    ]
  },
  {
    tag: "Finance", color: "#0d9488",
    keywords: [
      "finance","money","invest","stock","crypto","budget","tax","savings",
      "loan","mortgage","debt","profit","expense","401k","retirement","dividend",
      "portfolio","trading","bitcoin","etf","options","interest rate",
      "inflation","recession","personal finance","financial planning","net worth",
      "credit score","credit card","insurance","cash flow","income","real estate"
    ]
  },
  {
    tag: "Food", color: "#65a30d",
    keywords: [
      "recipe","cook","cooking","food","meal","dinner","lunch","breakfast","bake",
      "baking","restaurant","cuisine","ingredient","dish","flavor","taste",
      "vegan","vegetarian","keto","paleo","gluten","dairy","meal prep","grocery"
    ]
  },
  {
    tag: "Travel", color: "#f59e0b",
    keywords: [
      "travel","trip","vacation","holiday","flight","hotel","airbnb","booking",
      "destination","itinerary","passport","visa","airport","cruise","road trip",
      "backpacking","hostel","resort","beach","mountain","tour","travel guide"
    ]
  }
];

function generateTag(title) {
  if (!title || typeof title !== "string") return { tag: "General", color: "#6b7280" };
  const lower = title.toLowerCase();
  for (const rule of CATEGORY_RULES) {
    if (rule.keywords.some(kw => lower.includes(kw))) return { tag: rule.tag, color: rule.color };
  }
  return { tag: "General", color: "#6b7280" };
}

function getAllCategories() {
  return [
    { tag: "All", color: "#6b7280" },
    ...CATEGORY_RULES,
    { tag: "General", color: "#6b7280" }
  ];
}
