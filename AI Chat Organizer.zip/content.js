/**
 * content.js — AI Conversation Organizer v2.2
 *
 * FIXES in v2.2:
 *
 *  Fix 1 — startMessagesObserver() no longer depends on captureConversation()
 *    Observer now starts unconditionally in init(), not inside .then().
 *    This fixes the case where the conversation was already saved and
 *    captureConversation returned early, leaving the observer never attached.
 *
 *  Fix 2 — scheduleTopicScan() always fires, even on duplicate conversations
 *    captureConversation() now calls scheduleTopicScan() regardless of whether
 *    the conversation is new or already stored. Previously it only scanned on
 *    result.saved === true, which meant existing conversations never got new topics.
 *
 *  Fix 3 — URL comparison uses canonical path, not full href
 *    updateTopics() now matches by the conversation path (/c/<id>) instead of
 *    the full href. This survives query strings like ?model=gpt-4 that ChatGPT
 *    sometimes appends, which previously caused findIndex to return -1 silently.
 *
 *  Fix 4 — Added "General/Tech" category for consumer tech (iphone, android, etc.)
 *    iPhone, Android, Apple, Samsung, laptop, phone etc. now map to "Tech"
 *    which is separate from "AI/Tech" (coding/ML). Also added many more
 *    everyday keywords that were missing across all categories.
 *
 * PRIVACY: unchanged — message text read locally, discarded, only tag labels stored.
 */

// ── Constants ─────────────────────────────────────────────
const PLATFORM            = "ChatGPT";
const CONVERSATION_URL_RE = /\/(c|chat)\/[a-zA-Z0-9_-]{6,}/;
const TITLE_DEBOUNCE_MS   = 1800;
const TOPICS_DEBOUNCE_MS  = 1500;

// ── State ─────────────────────────────────────────────────
let titleDebounce    = null;
let topicsDebounce   = null;
let titleObserver    = null;
let messagesObserver = null;
let lastAttemptedKey = null;
let currentPath      = window.location.pathname;

// ── Topic rules ───────────────────────────────────────────
// Expanded keyword lists. Keep in sync with tagging.js.
const TOPIC_RULES = [
  {
    tag: "Health", color: "#16a34a",
    kw: [
      "health","diet","stress","sleep","skin","skincare","acne","ovary","ovaries",
      "mental health","anxiety","depression","nutrition","vitamin","medicine","doctor",
      "symptom","wellness","therapy","pain","headache","disease","hair","weight loss",
      "moisturizer","sunscreen","serum","hormones","period","pregnancy","blood pressure",
      "diabetes","allergy","inflammation","immune","gut","digestion","mental","clinic",
      "prescription","supplement","workout plan","calories burned","bmi","body fat",
      "dermatology","skincare routine","anti-aging","spf","retinol","collagen"
    ]
  },
  {
    tag: "Gym", color: "#ea580c",
    kw: [
      "gym","workout","protein","exercise","fitness","muscle","weight lifting",
      "lift","cardio","training","bench press","squat","run","marathon","calories",
      "bulk","cut","gains","crossfit","yoga","stretching","push up","pull up",
      "kettlebell","dumbbell","barbell","hiit","plank","abs","bicep","tricep","glutes"
    ]
  },
  {
    tag: "Career", color: "#7c3aed",
    kw: [
      "job","resume","cv","interview","career","work","salary","hire","hiring",
      "linkedin","portfolio","cover letter","promotion","freelance","internship",
      "job offer","negotiation","manager","employee","performance review",
      "resignation","layoff","fired","work from home","remote work","side hustle",
      "networking","job search","recruiter","headhunter","linkedin profile"
    ]
  },
  {
    tag: "AI/Tech", color: "#2563eb",
    kw: [
      "machine learning","python","model","rag","gpt","llm","neural network",
      "deep learning","programming","api","javascript","react","sql","database",
      "algorithm","data science","tensorflow","pytorch","automation","software",
      "developer","debug","typescript","cloud","aws","docker","kubernetes",
      "git","backend","frontend","devops","microservices","rest api","graphql",
      "web scraping","data pipeline","neural","artificial intelligence","chatbot",
      "prompt engineering","fine tuning","embeddings","vector database","langchain"
    ]
  },
  {
    // Consumer electronics / everyday tech — separate from AI/Tech
    tag: "Tech", color: "#0ea5e9",
    kw: [
      "iphone","android","samsung","apple","macbook","laptop","computer","pc",
      "windows","macos","linux","phone","tablet","ipad","pixel","smartphone",
      "airpods","headphones","speaker","monitor","keyboard","mouse","graphics card",
      "gpu","cpu","ram","storage","ssd","hard drive","wifi","router","internet",
      "app","software","update","battery","charger","cable","usb","bluetooth",
      "smartwatch","apple watch","camera","gaming","ps5","xbox","nintendo","steam",
      "streaming","netflix","spotify","youtube","social media","instagram","tiktok",
      "facebook","twitter","reddit","tech review","gadget","device","smart home",
      "alexa","siri","google assistant","cybersecurity","vpn","password","hack"
    ]
  },
  {
    tag: "Startup", color: "#db2777",
    kw: [
      "startup","business idea","product","saas","mvp","founder","investor",
      "pitch","revenue","market","launch","entrepreneur","venture","funding",
      "b2b","b2c","growth","monetize","brand","go-to-market","customer acquisition",
      "churn","mrr","arr","burn rate","runway","seed round","series a",
      "product market fit","user research","competitive analysis","business model",
      "value proposition","landing page","conversion","retention"
    ]
  },
  {
    tag: "Writing", color: "#d97706",
    kw: [
      "write","essay","blog","article","story","email","letter","content",
      "copywriting","edit","draft","poem","script","novel","summarize","summary",
      "report","thesis","grammar","proofreading","headline","caption","tweet",
      "press release","newsletter","substack","copywrite","paraphrase","rewrite",
      "tone","voice","paragraph","outline","creative writing","fiction","nonfiction"
    ]
  },
  {
    tag: "Finance", color: "#0d9488",
    kw: [
      "finance","money","invest","stock","crypto","budget","tax","savings",
      "loan","mortgage","debt","profit","expense","401k","retirement","dividend",
      "portfolio","trading","bitcoin","etf","options","hedge","interest rate",
      "inflation","recession","personal finance","financial planning","net worth",
      "credit score","credit card","bank","insurance","cash flow","income","expense",
      "invoice","accounting","bookkeeping","payroll","rent","real estate"
    ]
  },
  {
    tag: "Food", color: "#65a30d",
    kw: [
      "recipe","cook","cooking","food","meal","dinner","lunch","breakfast","bake",
      "baking","restaurant","cuisine","ingredient","dish","flavor","taste","eat",
      "nutrition","vegan","vegetarian","keto","paleo","gluten","dairy","allergy",
      "meal prep","grocery","grocery list","chef","kitchen","oven","grill","bbq"
    ]
  },
  {
    tag: "Travel", color: "#f59e0b",
    kw: [
      "travel","trip","vacation","holiday","flight","hotel","airbnb","booking",
      "destination","itinerary","passport","visa","airport","cruise","road trip",
      "backpacking","hostel","resort","beach","mountain","city","country","tour",
      "travel guide","things to do","best time to visit","weather","currency"
    ]
  }
];

// ── Helper: canonical conversation ID from URL ────────────
// Extracts just "/c/<id>" from the full URL so query strings
// like ?model=gpt-4 don't break the match.
function getConvoPath(urlStr) {
  try {
    const path = new URL(urlStr).pathname;
    const m    = path.match(/\/(c|chat)\/[a-zA-Z0-9_-]{6,}/);
    return m ? m[0] : path;
  } catch {
    return urlStr;
  }
}

// ── Topic detection ───────────────────────────────────────
function detectTopicsFromText(text) {
  if (!text || text.length < 2) return [];
  const lower = text.toLowerCase();
  const found = [];
  for (const rule of TOPIC_RULES) {
    const matched = rule.kw.some(k => {
      // Short keywords (≤4 chars) use word-boundary matching to prevent
      // substring false positives like "eat" matching "features"
      if (k.length <= 4) {
        return new RegExp("\\b" + k.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "\\b").test(lower);
      }
      return lower.includes(k);
    });
    if (matched) found.push(rule.tag);
  }
  return found;
}

// ── Page guard ────────────────────────────────────────────
function isConversationPage() {
  return CONVERSATION_URL_RE.test(window.location.pathname);
}

function isGenericTitle(t) {
  if (!t) return true;
  return ["new chat","chatgpt","untitled","chat",""].includes(t.toLowerCase().trim());
}

// ── Title extraction ──────────────────────────────────────
function extractTitle() {
  const raw = (document.title || "").trim();
  const cleaned = raw
    .replace(/\s*[-–—]\s*ChatGPT\s*$/i, "")
    .replace(/^ChatGPT\s*[-–—]\s*/i, "")
    .trim();
  if (cleaned && !isGenericTitle(cleaned)) return cleaned;

  const navSelectors = [
    'nav [aria-current="page"]',
    'nav a[aria-current="page"]',
    'nav .bg-token-sidebar-surface-secondary',
  ];
  for (const sel of navSelectors) {
    const text = document.querySelector(sel)?.textContent?.trim();
    if (text && !isGenericTitle(text) && text.length > 2) return text;
  }
  return null;
}

// ── Scan all visible user messages for topics ─────────────
function scanUserMessagesForTopics() {
  const allTopics = new Set();

  // Try each selector in order — use the first one that finds elements
  const selectors = [
    '[data-message-author-role="user"] .whitespace-pre-wrap',
    '[data-message-author-role="user"] p',
    '[data-message-author-role="user"]',
  ];

  for (const sel of selectors) {
    const elements = document.querySelectorAll(sel);
    if (elements.length === 0) continue;

    elements.forEach(el => {
      const text = el.textContent?.trim() || "";
      detectTopicsFromText(text).forEach(t => allTopics.add(t));
    });
    break; // stop at first working selector
  }

  return Array.from(allTopics);
}

// ── Core capture ──────────────────────────────────────────
async function captureConversation() {
  if (!isConversationPage()) return;

  const url   = window.location.href;
  const title = extractTitle();

  if (!title || isGenericTitle(title)) {
    setTimeout(captureConversation, 3000);
    return;
  }

  const key = url + "::" + title;
  if (lastAttemptedKey === key) return;
  lastAttemptedKey = key;

  try {
    await saveConversation({ title, url, platform: PLATFORM });
  } catch (err) {
    console.warn("[AI Organizer] Save error:", err);
  }

  // FIX 2: Always scan topics — whether this is a new save OR a duplicate.
  // Previously this only ran when result.saved === true, so existing
  // conversations never got their topics updated via captureConversation.
  scheduleTopicScan();
}

// ── Topic scanning ────────────────────────────────────────
async function scanAndUpdateTopics() {
  if (!isConversationPage()) return;

  const url    = window.location.href;
  const topics = scanUserMessagesForTopics();

  if (topics.length === 0) return;

  try {
    await updateTopics(url, topics);
  } catch (err) {
    console.warn("[AI Organizer] Topic update error:", err);
  }
}

function scheduleTopicScan() {
  clearTimeout(topicsDebounce);
  topicsDebounce = setTimeout(scanAndUpdateTopics, TOPICS_DEBOUNCE_MS);
}

function debouncedCapture() {
  clearTimeout(titleDebounce);
  titleDebounce = setTimeout(captureConversation, TITLE_DEBOUNCE_MS);
}

// ── Title observer ────────────────────────────────────────
function startTitleObserver() {
  if (titleObserver) titleObserver.disconnect();
  const titleEl = document.querySelector("title");
  if (!titleEl) { setTimeout(startTitleObserver, 500); return; }
  titleObserver = new MutationObserver(() => debouncedCapture());
  titleObserver.observe(titleEl, { childList: true, characterData: true, subtree: true });
}

// ── Message observer ──────────────────────────────────────
function startMessagesObserver() {
  if (messagesObserver) messagesObserver.disconnect();

  // Find the best container to observe
  const target =
    document.querySelector('main') ||
    document.querySelector('[role="main"]') ||
    document.querySelector('#__next') ||
    document.body;

  if (!target) { setTimeout(startMessagesObserver, 1000); return; }

  messagesObserver = new MutationObserver(mutations => {
    const hasNewNodes = mutations.some(m => m.addedNodes.length > 0);
    if (!hasNewNodes) return;
    scheduleTopicScan();
  });

  messagesObserver.observe(target, {
    childList:     true,
    subtree:       true,
    attributes:    false,
    characterData: false,
  });

  console.log("[AI Organizer] v2.2 message observer attached");
}

// ── SPA navigation ────────────────────────────────────────
function handleRouteChange() {
  const newPath = window.location.pathname;
  if (newPath !== currentPath) {
    currentPath      = newPath;
    lastAttemptedKey = null;
    if (messagesObserver) messagesObserver.disconnect();
    debouncedCapture();
    setTimeout(startMessagesObserver, 1500);
  }
}

const _origPush = history.pushState.bind(history);
history.pushState = function (...args) {
  _origPush(...args);
  handleRouteChange();
};
window.addEventListener("popstate", handleRouteChange);

// ── Init ─────────────────────────────────────────────────
function init() {
  console.log("[AI Organizer] v2.2 loaded");

  startTitleObserver();

  // FIX 1: Start the message observer unconditionally after page load.
  // Previously it was nested inside captureConversation().then(...)
  // which never fired when the conversation was already saved (duplicate).
  setTimeout(() => {
    captureConversation();       // save if new, scan topics either way
    startMessagesObserver();     // always attach — independent of save result
    scheduleTopicScan();         // scan existing messages already on screen
  }, 2000);
}

init();
