/**
 * storage.js — AI Conversation Organizer v2.1
 *
 * DATA MODEL CHANGE in v2.1:
 *   Added `topics` field — array of all detected topic tags.
 *   The primary `tag` is preserved for backwards compat.
 *   `topics` is the full set including multi-topic detections.
 *
 * Record shape:
 * {
 *   id:          string    — URL-hash
 *   title:       string    — conversation title
 *   summary:     string    — one-line description from title keywords
 *   url:         string    — full URL
 *   platform:    string    — "ChatGPT"
 *   timestamp:   string    — ISO 8601
 *   tag:         string    — PRIMARY topic tag (from title, backwards compat)
 *   tagColor:    string    — hex for primary tag
 *   topics:      string[]  — ALL detected topics (title + message scans)
 *   customTags:  string[]  — user-assigned labels
 *   important:   boolean   — bookmarked
 * }
 */

const STORAGE_KEY     = "aco_conversations";
const CUSTOM_TAGS_KEY = "aco_custom_tags";

function generateId(url) {
  let hash = 0;
  for (let i = 0; i < url.length; i++) {
    hash = (hash << 5) - hash + url.charCodeAt(i);
    hash |= 0;
  }
  return "aco_" + Math.abs(hash).toString(36);
}

function generateSummary(title) {
  if (!title) return "";
  const t = title.toLowerCase();
  const patterns = [
    { rx: /\bhow (to|do|can|should)\b/,     prefix: "How-to guide:" },
    { rx: /\bwhy\b/,                         prefix: "Explanation about:" },
    { rx: /\bwhat (is|are|does|was)\b/,      prefix: "Overview of:" },
    { rx: /\bbest\b/,                         prefix: "Best-of comparison:" },
    { rx: /\bdebug|error|fix|broken|issue\b/, prefix: "Troubleshooting:" },
    { rx: /\bwrite|draft|generate|create\b/,  prefix: "Content creation:" },
    { rx: /\bplan|strategy|roadmap\b/,        prefix: "Planning session:" },
    { rx: /\blearn|understand|explain\b/,     prefix: "Learning session:" },
    { rx: /\bcompare|vs\.?|versus\b/,         prefix: "Comparison:" },
    { rx: /\bcode|implement|build|develop\b/,  prefix: "Coding help:" },
    { rx: /\breview|feedback|improve\b/,      prefix: "Review & feedback:" },
    { rx: /\bidea|brainstorm\b/,              prefix: "Brainstorming:" },
    { rx: /\bhelp|assist|support\b/,          prefix: "Assistance with:" },
  ];
  for (const { rx, prefix } of patterns) {
    if (rx.test(t)) return `${prefix} ${title.charAt(0).toUpperCase() + title.slice(1)}`;
  }
  return `Discussion: ${title.charAt(0).toUpperCase() + title.slice(1)}`;
}

// ── Conversations ─────────────────────────────────────────
async function loadConversations() {
  return new Promise(resolve =>
    chrome.storage.local.get([STORAGE_KEY], r => resolve(r[STORAGE_KEY] || []))
  );
}

async function saveConversation(metadata) {
  const conversations = await loadConversations();
  if (conversations.some(c => c.url === metadata.url)) return { saved: false, record: null };

  const { tag, color } = generateTag(metadata.title);
  const record = {
    id:         generateId(metadata.url),
    title:      metadata.title || "Untitled Conversation",
    summary:    generateSummary(metadata.title),
    url:        metadata.url,
    platform:   metadata.platform || "ChatGPT",
    timestamp:  new Date().toISOString(),
    tag,
    tagColor:   color,
    topics:     tag !== "General" ? [tag] : [],  // seed with primary tag
    customTags: [],
    important:  false
  };
  conversations.unshift(record);
  return new Promise(resolve =>
    chrome.storage.local.set({ [STORAGE_KEY]: conversations }, () => resolve({ saved: true, record }))
  );
}

/**
 * Updates the `topics` array for a conversation identified by URL.
 * Merges new topics with existing ones — never removes, only adds.
 * Also updates the primary `tag` to the first detected topic if
 * the current tag is "General".
 *
 * Called by content.js whenever new user messages are detected.
 * The actual message text is NOT passed here — only the tag names
 * that were derived from keyword matching on the content script side.
 *
 * @param {string}   url        — conversation URL
 * @param {string[]} newTopics  — array of topic tag names to merge in
 */
// Extracts the canonical /c/<id> path from a full URL.
// This prevents query strings like ?model=gpt-4 from breaking the match.
function getCanonicalPath(urlStr) {
  try {
    const path = new URL(urlStr).pathname;
    const m = path.match(/\/(c|chat)\/[a-zA-Z0-9_-]{6,}/);
    return m ? m[0] : path;
  } catch { return urlStr; }
}

async function updateTopics(url, newTopics) {
  if (!newTopics || newTopics.length === 0) return;

  const conversations = await loadConversations();

  // FIX 3: Match by canonical path (/c/<id>), not full URL.
  // The stored c.url may lack query params that window.location.href has,
  // or vice versa. Matching on path only is always correct.
  const incomingPath = getCanonicalPath(url);
  const idx = conversations.findIndex(c => getCanonicalPath(c.url) === incomingPath);

  // If conversation not yet saved, nothing to update
  if (idx === -1) return;

  const convo       = conversations[idx];
  const existing    = new Set(convo.topics || []);
  const before      = existing.size;

  newTopics.forEach(t => existing.add(t));

  // No change — bail early to avoid unnecessary storage writes
  if (existing.size === before) return;

  const updatedTopics = Array.from(existing);

  // Upgrade "General" primary tag to the first real topic found
  let updatedTag      = convo.tag;
  let updatedTagColor = convo.tagColor;
  if (convo.tag === "General" && updatedTopics.length > 0) {
    updatedTag      = updatedTopics[0];
    // Look up the color for this tag from CATEGORY_RULES (available in tagging.js scope)
    const rule = (typeof CATEGORY_RULES !== "undefined")
      ? CATEGORY_RULES.find(r => r.tag === updatedTag)
      : null;
    if (rule) updatedTagColor = rule.color;
  }

  conversations[idx] = {
    ...convo,
    tag:      updatedTag,
    tagColor: updatedTagColor,
    topics:   updatedTopics,
  };

  return new Promise(resolve =>
    chrome.storage.local.set({ [STORAGE_KEY]: conversations }, () => {
      console.log(`[AI Organizer] Topics updated for "${convo.title}": [${updatedTopics.join(", ")}]`);
      resolve();
    })
  );
}

async function toggleImportant(id) {
  const conversations = await loadConversations();
  let newValue = false;
  const updated = conversations.map(c => {
    if (c.id === id) { newValue = !c.important; return { ...c, important: newValue }; }
    return c;
  });
  return new Promise(resolve =>
    chrome.storage.local.set({ [STORAGE_KEY]: updated }, () => resolve(newValue))
  );
}

async function updateConversationCustomTags(id, customTags) {
  const conversations = await loadConversations();
  const updated = conversations.map(c => c.id === id ? { ...c, customTags } : c);
  return new Promise(resolve => chrome.storage.local.set({ [STORAGE_KEY]: updated }, resolve));
}

async function deleteConversation(id) {
  const conversations = await loadConversations();
  const filtered = conversations.filter(c => c.id !== id);
  return new Promise(resolve => chrome.storage.local.set({ [STORAGE_KEY]: filtered }, resolve));
}

async function clearAllConversations() {
  return new Promise(resolve => chrome.storage.local.remove([STORAGE_KEY], resolve));
}

// ── Custom Tag Definitions ────────────────────────────────
async function loadCustomTagDefinitions() {
  return new Promise(resolve =>
    chrome.storage.local.get([CUSTOM_TAGS_KEY], r => resolve(r[CUSTOM_TAGS_KEY] || []))
  );
}

async function saveCustomTagDefinition(label, color) {
  const tags = await loadCustomTagDefinitions();
  if (tags.some(t => t.label.toLowerCase() === label.toLowerCase())) return { saved: false };
  tags.push({ label: label.trim(), color });
  return new Promise(resolve =>
    chrome.storage.local.set({ [CUSTOM_TAGS_KEY]: tags }, () => resolve({ saved: true }))
  );
}

async function deleteCustomTagDefinition(label) {
  const [tags, conversations] = await Promise.all([loadCustomTagDefinitions(), loadConversations()]);
  const updatedTags   = tags.filter(t => t.label !== label);
  const updatedConvos = conversations.map(c => ({
    ...c, customTags: (c.customTags || []).filter(ct => ct !== label)
  }));
  return new Promise(resolve =>
    chrome.storage.local.set({ [CUSTOM_TAGS_KEY]: updatedTags, [STORAGE_KEY]: updatedConvos }, resolve)
  );
}

// ── Analytics ─────────────────────────────────────────────
async function getAnalytics(period) {
  const conversations = await loadConversations();
  const ms   = period === "week" ? 7 * 86400000 : 30 * 86400000;
  const from = Date.now() - ms;
  const prev = Date.now() - ms * 2;

  const inPeriod   = conversations.filter(c => new Date(c.timestamp).getTime() >= from);
  const prevPeriod = conversations.filter(c => {
    const t = new Date(c.timestamp).getTime();
    return t >= prev && t < from;
  });

  // Count each topic from the `topics` array (multi-topic aware)
  const tagCounts = {};
  inPeriod.forEach(c => {
    const topicsToCount = (c.topics && c.topics.length > 0) ? c.topics : [c.tag];
    topicsToCount.forEach(t => { tagCounts[t] = (tagCounts[t] || 0) + 1; });
  });

  const dailyCounts = {};
  inPeriod.forEach(c => {
    const day = c.timestamp.slice(0, 10);
    dailyCounts[day] = (dailyCounts[day] || 0) + 1;
  });

  let peakDay = null, peakCount = 0;
  Object.entries(dailyCounts).forEach(([day, count]) => {
    if (count > peakCount) { peakDay = day; peakCount = count; }
  });

  const sortedTags  = Object.entries(tagCounts).sort((a, b) => b[1] - a[1]);
  const hourCounts  = Array(24).fill(0);
  inPeriod.forEach(c => { hourCounts[new Date(c.timestamp).getHours()]++; });

  // Multi-topic conversations stat
  const multiTopicCount = inPeriod.filter(c => (c.topics || []).length > 1).length;

  return {
    period,
    total:          inPeriod.length,
    prevTotal:      prevPeriod.length,
    tagCounts,
    sortedTags,
    dailyCounts,
    peakDay,
    peakCount,
    bookmarked:     inPeriod.filter(c => c.important).length,
    hourCounts,
    multiTopicCount,
    allTime:        conversations.length
  };
}
